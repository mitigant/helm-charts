# Mitigant KSPM Operator
